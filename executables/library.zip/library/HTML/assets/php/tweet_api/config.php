<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', '43gMOggUNJygCwoO2aH40PqWd');
    define('CONSUMER_SECRET', 'yOCB9xETIKKBuGbNsCwwA8k2chudSErxjP2TdLtAcQLMIr3N2V');

    // User Access Token
    define('ACCESS_TOKEN', '1612079018-bG0awBySmSik3m00AIMmpRP8nHVm4vaB54mQ4NH');
    define('ACCESS_SECRET', 'TBlpnBDwFpmWVbPwXDXUo9dADmz0phkbxpU3wjCuKmp7s');