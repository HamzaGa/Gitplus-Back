import { Injectable } from '@angular/core';
import { User } from '../home/user';

@Injectable()
export class AuthService {


  constructor() {
   }


    get isLoggedIn() {
      if(window.localStorage.getItem("auth_key")=="yes")
      return true;
      else return(false);
    }
  
    get isSuperAdmin() {
      return true;
    }

}
