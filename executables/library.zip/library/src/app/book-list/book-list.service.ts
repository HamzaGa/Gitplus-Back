import { Injectable } from '@angular/core';
import { HttpModule,Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import {Book} from './book';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/filter';

@Injectable()
export class BookListService {
  
  private _url = "http://localhost:59397/api/books"; 

  constructor(private _http: Http) {}

  getBooks(): Observable<Book[]> {
    return this._http.get(this._url)
        .map((response: Response) => <Book[]>response.json());

}
  
}
