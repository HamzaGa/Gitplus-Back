export interface Book {
 Id:number,
 Title:string,
 Year:number,
 Price:number,
 Genre:string,
 Rating:string,
 Img: string,
 AuthorId:number
}
