import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { BookListService } from './book-list.service';
import { Book } from './book';



@Injectable()
@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

bookList:Array<Book>;
errorMessage:any;
constructor(bookService:BookListService) 
  {
    bookService.getBooks().subscribe(bookList => this.bookList = bookList);
  }

  ngOnInit() {
    
  }

}
