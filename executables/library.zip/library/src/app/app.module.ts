import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { LibraryComponent } from './library/library.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { BookListComponent } from './book-list/book-list.component';
import { FooterComponent } from './footer/footer.component';
import { BookListService } from './book-list/book-list.service';
import {HttpModule} from '@angular/http';
import { FormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AuthGuard } from './auth/guards/auth.guard';
import { AuthService } from './auth/auth.service';
import { Router } from '@angular/router/src/router';
import { UserService } from './home/user.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LibraryComponent,
    HeaderComponent,
    BookListComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    Ng2SearchPipeModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      {path:'', redirectTo:'home',pathMatch:'full'},
      {path:'library',component:LibraryComponent,canActivate: [AuthGuard]},
      {path:'home',component:HomeComponent}
    ]
    )
  ],
  providers: [BookListService,AuthService,AuthGuard,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
