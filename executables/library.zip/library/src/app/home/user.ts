export interface User {
    Id: number;
    Login: string;
    Password: string;
}
