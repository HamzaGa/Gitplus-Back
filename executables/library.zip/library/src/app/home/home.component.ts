import { Component, OnInit, Injectable } from '@angular/core';
import {User} from './user';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { UserService } from './user.service';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: []
})
@Injectable()
export class HomeComponent implements OnInit {

  user : User;
  authS:AuthService;
  private router:Router;
  loginOrLogout:String;
  userList:Array<User>;

  constructor(router:Router,authService:AuthService,userService:UserService) 
  {
    userService.getUsers().subscribe(userList => this.userList = userList);    
    this.authS=authService; 
    this.router=router; 
    if(window.localStorage.getItem("auth_key")=="yes")
    this.loginOrLogout="logged";
    else this.loginOrLogout="nonLogged";  
  }

  ngOnInit() {
    this.user = {
      Id : 0,
      Login: "",
      Password:""
    }
  }

  onSubmit(){
    var x : Boolean;
    x=true;
    for(var i = 0, len = this.userList.length; i < len; i++) {
      if (this.userList[i].Login === this.user.Login && this.userList[i].Password==this.user.Password) {
          x = true;
          break;
      }          
           else x = false;
        }
      

    if(x==true)
    {
      this.router.navigate(['library']);
      window.localStorage.setItem("auth_key","yes");
      console.log(window.localStorage.getItem("auth_key"));
    }
    else {
      window.localStorage.setItem("auth_key","No");      
      alert("Bad credentials !")
    }

  }

  onLogout(){
    this.router.navigate(['']);    
    window.localStorage.removeItem("auth_key");
  }

}
